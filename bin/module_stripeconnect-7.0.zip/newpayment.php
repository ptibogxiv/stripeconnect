<?php
/* Copyright (C) 2017		Alexandre Spangaro		<aspangaro@zendsi.com>
 * Copyright (C) 2017		Saasprov				<saasprov@gmail.com>
 * Copyright (C) 2017       Laurent Destailleur		<eldy@users.sourceforge.net>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
*  \file       htdocs/public/stripe/newpayment.php
*  \ingroup    Stripe
*  \brief      Page to do payment with Stripe
*/

define("NOLOGIN",1);		// This means this output page does not require to be logged.
define("NOCSRFCHECK",1);	// We accept to go on this page from external web site.

// For MultiCompany module.
// Do not use GETPOST here, function is not defined and define must be done before including main.inc.php
// TODO This should be useless. Because entity must be retreive from object ref and not from url.
$entity=(! empty($_GET['entity']) ? (int) $_GET['entity'] : (! empty($_POST['entity']) ? (int) $_POST['entity'] : 1));
if (is_numeric($entity)) define("DOLENTITY", $entity);

$res=0;
if (! $res && file_exists("../main.inc.php")) $res=@include("../main.inc.php");			// to work if your module directory is into dolibarr root htdocs directory
if (! $res && file_exists("../../main.inc.php")) $res=@include("../../main.inc.php");		// to work if your module directory is into a subdir of root htdocs directory
if (! $res && file_exists("../../../main.inc.php")) $res=@include("../../../main.inc.php");		// to work if your module directory is into a subdir of root htdocs directory
if (! $res) die("Include of main fails");

//require_once DOL_DOCUMENT_ROOT.'/stripe/config.php';
require_once DOL_DOCUMENT_ROOT.'/societe/class/societe.class.php';
require_once DOL_DOCUMENT_ROOT.'/stripe/class/stripe.class.php';

// Security check
if (empty($conf->stripeconnect->enabled)) accessforbidden('',0,0,1);

$langs->load("main");
$langs->load("companies");
$langs->load("other");
$langs->load("paybox");     // File with generic data
$langs->load("paypal");
$langs->load("stripe");

$action=GETPOST('action','alpha');
$validation=GETPOST('validation','alpha');
$suffix=GETPOST("suffix",'alpha');
$amount=price2num(GETPOST("amount"));
if (! GETPOST("currency",'alpha')) $currency=$conf->currency;
else $currency=GETPOST("currency",'alpha');
$ORIGIN=GETPOST("origin",'alpha');
$ref=$REF=GETPOST('ref','alpha');
$CUSTOMERSTRIPE=$customerstripe=GETPOST('customerstripe','alpha');
$TAG=GETPOST("tag",'alpha');
$FULLTAG=GETPOST("fulltag",'alpha');		// fulltag is tag with more informations
$SECUREKEY=GETPOST("securekey");

if (! $action)
{
    if (! GETPOST("amount") && ! GETPOST("origin"))
    {
        //dol_print_error('',$langs->trans('ErrorBadParameters')." - amount or origin");
        //exit;
    }
    if (is_numeric($amount) && ! GETPOST("tag") && ! GETPOST("origin"))
    {
        dol_print_error('',$langs->trans('ErrorBadParameters')." - tag or origin");
        exit;
    }
    if (GETPOST("origin") && ! GETPOST("ref"))
    {
        dol_print_error('',$langs->trans('ErrorBadParameters')." - ref");
        exit;
    }
}

$urlwithroot=DOL_MAIN_URL_ROOT;						// This is to use same domain name than current

//$urlok=$urlwithroot.'/public/stripe/paymentok.php?';
//$urlko=$urlwithroot.'/public/stripe/paymentko.php?';
$urlok=$urlwithroot.dol_buildpath('/stripeconnect/newpayment.php?', 1);
$urlko=$urlwithroot.dol_buildpath('/stripeconnect/newpayment.php?', 1);
$url=$urlwithroot.dol_buildpath('/stripeconnect/newpayment.php?', 1);
$urldefault=$urlwithroot.dol_buildpath('/stripeconnect/newpayment.php?', 1);
 
 
//if (! preg_match('/'.preg_quote('PM=stripe','/').'/', $FULLTAG)) $FULLTAG.=($FULLTAG?'.':'').'PM=stripe';

$stripeconnect=new StripeConnexion($db);

if (! empty($ORIGIN))
{
    $urlok.='origin='.urlencode($ORIGIN).'&';
    $urlko.='origin='.urlencode($ORIGIN).'&';
    $url.='origin='.urlencode($ORIGIN).'&';
}
if (! empty($REF))
{
    $urlok.='ref='.urlencode($REF).'&';
    $urlko.='ref='.urlencode($REF).'&';
    $url.='ref='.urlencode($REF).'&';    
}
if (! empty($TAG))
{
    $urlok.='tag='.urlencode($TAG).'&';
    $urlko.='tag='.urlencode($TAG).'&';
    $url.='tag='.urlencode($TAG).'&';    
}
if (! empty($FULLTAG))
{
    $urlok.='fulltag='.urlencode($FULLTAG).'&';
    $urlko.='fulltag='.urlencode($FULLTAG).'&';
    $url.='';   
}
if (! empty($SECUREKEY))
{
    $urlok.='securekey='.urlencode($SECUREKEY).'&';
    $urlko.='securekey='.urlencode($SECUREKEY).'&';
    $url.='securekey='.urlencode($SECUREKEY).'&';   
}
if (! empty($entity))
{
    $urlok.='entity='.urlencode($entity).'&';
    $urlko.='entity='.urlencode($entity).'&';
    $url.='entity='.urlencode($entity).'&';    
}

    $urlok.='validation=ok&';
    $urlko.='validation=ko&';
    $url.='';    

$urlok=preg_replace('/&$/','',$urlok);  // Remove last &
$urlko=preg_replace('/&$/','',$urlko);  // Remove last &
$url=preg_replace('/&$/','',$url);  // Remove last &

// Check security token
$valid=true;
if (! empty($conf->global->PAYMENT_SECURITY_TOKEN))   // obligation de secure key
{

    if (! empty($conf->global->PAYMENT_SECURITY_TOKEN_UNIQUE))
    {
        if ($ORIGIN && $REF) $token = dol_hash($conf->global->PAYMENT_SECURITY_TOKEN . $ORIGIN . $REF, 2);    // Use the source in the hash to avoid duplicates if the references are identical
        else $token = dol_hash($conf->global->PAYMENT_SECURITY_TOKEN, 2);
    
    }
    else
    {
        $token = $conf->global->PAYMENT_SECURITY_TOKEN;
    }
    if ($SECUREKEY != $token) $valid=false;
      print $token;  //a suprimer
    if (! $valid)
    {
        header("Location: ".$urldefault);
        exit;
//print 'SECUREKEY='.$SECUREKEY.' token='.$token.' valid='.$valid;
    }

}

if ($validation)
{
$os = array("ok", "ko");
if (!in_array($validation, $os)) {     
        header("Location: ".$url);
        exit;}
}

// Common variables
$creditor=$mysoc->name;
$paramcreditor='STRIPE_CREDITOR_'.$suffix;
if (! empty($conf->global->$paramcreditor)) $creditor=$conf->global->$paramcreditor;
else if (! empty($conf->global->STRIPE_CREDITOR)) $creditor=$conf->global->STRIPE_CREDITOR;

/*
 * Actions
 */
if ($action != 'stripeSource' && GETPOST("source",'alpha') && GETPOST("client_secret",'alpha') && GETPOST("livemode",'alpha') && GETPOST("origin",'alpha')) {
$src = \Stripe\Source::retrieve("".GETPOST("source",'alpha')."",array("stripe_account" => $stripeconnect->GetStripeAccount($entity)));
if ($src->client_secret==GETPOST("client_secret",'alpha') && ($src->type == 'three_d_secure') && ($src->type == 'three_d_secure') && ($src->flow == 'redirect') && ($src->three_d_secure->authenticated==true)){
header('Location: '.$urlok);
exit;
}
else{
header('Location: '.$urlko);
exit;
}

}
if ($action == 'stripeSource')    // We click on button Create payment
{
    if (GETPOST('newamount')) $amount = GETPOST('newamount');
    else
    {
        setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv("Amount")), null, 'errors');
        $action = '';
    }
}


if ($action == 'delete' && GETPOST("source",'alpha') && GETPOST("customer",'alpha')) {
$cus=GETPOST("customer",'alpha');
$cu = \Stripe\Customer::retrieve("".$cus."",array("stripe_account" => $stripeconnect->GetStripeAccount($conf->entity)));
$src=GETPOST("source",'alpha');
$cu->sources->retrieve("$src")->delete();

header('Location: '.$url);
exit;
}

if ($action == 'charge')
{
    $arrayzerounitcurrency=array('BIF', 'CLP', 'DJF', 'GNF', 'JPY', 'KMF', 'KRW', 'MGA', 'PYG', 'RWF', 'VND', 'VUV', 'XAF', 'XOF', 'XPF');
    if (! in_array($currency, $arrayzerounitcurrency)) $amount=$amount * 100;

    dol_syslog("POST keys  : ".join(',', array_keys($_POST)), LOG_DEBUG, 0, '_stripe');
    dol_syslog("POST values: ".join(',', $_POST), LOG_DEBUG, 0, '_stripe');

    $stripeSource = GETPOST("stripeSource",'alpha');
    $email = GETPOST("stripeEmail",'alpha');

    dol_syslog("stripeToken = ".$stripeToken, LOG_DEBUG, 0, '_stripe');
    dol_syslog("stripeEmail = ".$stripeEmail, LOG_DEBUG, 0, '_stripe');

    $error = 0;

    try { 
dol_syslog("Create customer", LOG_DEBUG, 0, '_stripe');
if (GETPOST("save_source",'alpha')=='1') {
if ($entity!=1){
$tok = \Stripe\Source::create(array(
  "original_source" => "$stripeSource",
  "usage" => "reusable",
), array("stripe_account" => $stripeconnect->GetStripeAccount($conf->entity)));
$stripeSource=$tok->id;
}
else {
$stripeSource=$stripeSource;
}
$customer = \Stripe\Customer::retrieve("$customerstripe",array("stripe_account" => $stripeconnect->GetStripeAccount($conf->entity)));
$customer->sources->create(array("source" => "$stripeSource"));
$customer->default_source = "$stripeSource";
$customer->save(); 
} 

$source = \Stripe\Source::retrieve("$stripeSource",array("stripe_account" => $stripeconnect->GetStripeAccount($entity)));

$amount2=price2num($amount, 'MU');
if ($source->object=='source' && $source->type=='card' && isset($source->card->three_d_secure) && ($source->card->three_d_secure=='required' or $source->card->three_d_secure=='optional')){
$source2 = \Stripe\Source::create(array(
  "amount" => "$amount2",
  "currency" => "$currency",
  "type" => "three_d_secure",
  "three_d_secure" => array(
    "card" => "$stripeSource",
  ),
    "metadata" => array(
    "fulltag" => "$FULLTAG",
    "customer" => "$customerstripe"
  ),
  "redirect" => array(
    "return_url" => "$url"
  ),
),array("stripe_account" => $stripeconnect->GetStripeAccount($conf->entity)));
if ($source2->three_d_secure->authenticated==false && $source2->redirect->status=='succeeded') {
$charge=$stripeconnect->CreatePaymentStripe($amount2,$currency,$origin,$ref,$stripeSource,$customerstripe,$stripeconnect->GetStripeAccount($entity));
}
else {
        header("Location: ".$source2->redirect->url);
        exit;
}
        }
        else {
$charge=$stripeconnect->CreatePaymentStripe($amount2,$currency,$origin,$ref,$stripeSource,$customerstripe,$stripeconnect->GetStripeAccount($entity));
        }

    } catch(\Stripe\Error\Card $e) {
        // Since it's a decline, \Stripe\Error\Card will be caught
        $body = $e->getJsonBody();
        $err  = $body['error'];

        print('Status is:' . $e->getHttpStatus() . "\n");
        print('Type is:' . $err['type'] . "\n");
        print('Code is:' . $err['code'] . "\n");
        // param is '' in this case
        print('Param is:' . $err['param'] . "\n");
        print('Message is:' . $err['message'] . "\n");

        $error++;
        setEventMessages($e->getMessage(), null, 'errors');
        dol_syslog($e->getMessage(), LOG_WARNING, 0, '_stripe');
        $action='';
    } catch (\Stripe\Error\RateLimit $e) {
        // Too many requests made to the API too quickly
        $error++;
        dol_syslog($e->getMessage(), LOG_WARNING, 0, '_stripe');
        setEventMessages($e->getMessage(), null, 'errors');
        $action='';
    } catch (\Stripe\Error\InvalidRequest $e) {
        // Invalid parameters were supplied to Stripe's API
        $error++;
        dol_syslog($e->getMessage(), LOG_WARNING, 0, '_stripe');
        setEventMessages($e->getMessage(), null, 'errors');
        $action='';
    } catch (\Stripe\Error\Authentication $e) {
        // Authentication with Stripe's API failed
        // (maybe you changed API keys recently)
        $error++;
        dol_syslog($e->getMessage(), LOG_WARNING, 0, '_stripe');
        setEventMessages($e->getMessage(), null, 'errors');
        $action='';
    } catch (\Stripe\Error\ApiConnection $e) {
        // Network communication with Stripe failed
        $error++;
        dol_syslog($e->getMessage(), LOG_WARNING, 0, '_stripe');
        setEventMessages($e->getMessage(), null, 'errors');
        $action='';
    } catch (\Stripe\Error\Base $e) {
        // Display a very generic error to the user, and maybe send
        // yourself an email
        $error++;
        dol_syslog($e->getMessage(), LOG_WARNING, 0, '_stripe');
        setEventMessages($e->getMessage(), null, 'errors');
        $action='';
    } catch (Exception $e) {
        // Something else happened, completely unrelated to Stripe
        $error++;
        dol_syslog($e->getMessage(), LOG_WARNING, 0, '_stripe');
        setEventMessages($e->getMessage(), null, 'errors');
        $action='';
    }

	$_SESSION["onlinetoken"] = $stripeToken;
    $_SESSION["Payment_Amount"] = $amount;
    $_SESSION["currencyCodeType"] = $currency;
    $_SESSION["paymentType"] = '';
    $_SESSION['ipaddress'] = $_SERVER['REMOTE_ADDR'];  // Payer ip
    $_SESSION['payerID'] = is_object($customer)?$customer->id:'';
    $_SESSION['TRANSACTIONID'] = is_object($charge)?$charge->id:'';

    dol_syslog("Action charge stripe result=".$error." ip=".$_SESSION['ipaddress'], LOG_DEBUG, 0, '_stripe');
    dol_syslog("onlinetoken=".$_SESSION["onlinetoken"]." FinalPaymentAmt=".$_SESSION["FinalPaymentAmt"]." currencyCodeType=".$_SESSION["currencyCodeType"]." payerID=".$_SESSION['payerID']." TRANSACTIONID=".$_SESSION['TRANSACTIONID'], LOG_DEBUG, 0, '_stripe');
    dol_syslog("FULLTAG=".$FULLTAG, LOG_DEBUG, 0, '_stripe');
    dol_syslog("Now call the redirect to paymentok or paymentko", LOG_DEBUG, 0, '_stripe');

    if ($error)
    {
header("Location: ".$urlko);
exit;
    }
    else
    {
header("Location: ".$urlok);
exit;
    }

}


/*
 * View
 */

$head='';
if (! empty($conf->global->STRIPE_CSS_URL)) $head='<link rel="stylesheet" type="text/css" href="'.$conf->global->STRIPE_CSS_URL.'?lang='.$langs->defaultlang.'">'."\n";

$conf->dol_hide_topmenu=1;
$conf->dol_hide_leftmenu=1;

llxHeader($head, $langs->trans("PaymentForm"), '', '', 0, 0, '', '', '', 'onlinepaymentbody');

// Check link validity
if (! empty($ORIGIN) && in_array($ref, array('member_ref', 'contractline_ref', 'invoice_ref', 'order_ref', '')))
{
    $langs->load("errors");
    dol_print_error_email('BADREFINPAYMENTFORM', $langs->trans("ErrorBadLinkSourceSetButBadValueForRef", $ORIGIN, $ref));
    llxFooter();
    $db->close();
    exit;
}

if (empty($conf->global->STRIPE_LIVE))
{
    dol_htmloutput_mesg($langs->trans('YouAreCurrentlyInSandboxMode'),'','warning');
}

print '<span id="dolpaymentspan"></span>'."\n";
print '<div class="center">'."\n";
print '<form id="dolpaymentform" class="center" name="paymentform" action="'.$url.'" method="POST">'."\n";
print '<input type="hidden" name="token" value="'.$_SESSION['newtoken'].'">'."\n";
print '<input type="hidden" name="action" value="stripeSource">'."\n";
print '<input type="hidden" name="tag" value="'.GETPOST("tag",'alpha').'">'."\n";
print '<input type="hidden" name="suffix" value="'.GETPOST("suffix",'alpha').'">'."\n";
print '<input type="hidden" name="securekey" value="'.$SECUREKEY.'">'."\n";
print '<input type="hidden" name="entity" value="'.$entity.'" />';
print "\n";
print '<!-- Form to send a Stripe payment -->'."\n";
print '<!-- STRIPE_API_SANDBOX = '.$conf->global->STRIPE_API_SANDBOX.' -->'."\n";
print '<!-- creditor = '.$creditor.' -->'."\n";
print '<!-- urlok = '.$urlok.' -->'."\n";
print '<!-- urlko = '.$urlko.' -->'."\n";
print "\n";

print '<table id="dolpaymenttable" summary="Payment form" class="center">'."\n";

// Show logo (search order: logo defined by PAYBOX_LOGO_suffix, then PAYBOX_LOGO, then small company logo, large company logo, theme logo, common logo)
$width=0;
// Define logo and logosmall
$logosmall=$mysoc->logo_small;
$logo=$mysoc->logo;
$paramlogo='STRIPE_LOGO_'.$suffix;
if (! empty($conf->global->$paramlogo)) $logosmall=$conf->global->$paramlogo;
else if (! empty($conf->global->STRIPE_LOGO)) $logosmall=$conf->global->STRIPE_LOGO;
//print '<!-- Show logo (logosmall='.$logosmall.' logo='.$logo.') -->'."\n";
// Define urllogo
$urllogo='';
if (! empty($logosmall) && is_readable($conf->mycompany->dir_output.'/logos/thumbs/'.$logosmall))
{
    $urllogo=DOL_URL_ROOT.'/viewimage.php?modulepart=mycompany&amp;file='.urlencode('thumbs/'.$logosmall);
}
elseif (! empty($logo) && is_readable($conf->mycompany->dir_output.'/logos/'.$logo))
{
    $urllogo=DOL_URL_ROOT.'/viewimage.php?modulepart=mycompany&amp;file='.urlencode($logo);
    $width=96;
}
// Output html code for logo
if ($urllogo)
{
    print '<tr>';
    print '<td align="center"><img id="dolpaymentlogo" title="'.$title.'" src="'.$urllogo.'"';
    if ($width) print ' width="'.$width.'"';
    print '></td>';
    print '</tr>'."\n";
}

// Output introduction text
$text='';
if (! empty($conf->global->STRIPE_NEWFORM_TEXT))
{
    $langs->load("members");
    if (preg_match('/^\((.*)\)$/',$conf->global->STRIPE_NEWFORM_TEXT,$reg)) $text.=$langs->trans($reg[1])."<br>\n";
    else $text.=$conf->global->STRIPE_NEWFORM_TEXT."<br>\n";
    $text='<tr><td align="center"><br>'.$text.'<br></td></tr>'."\n";
}
if (empty($text))
{
    $text.='<tr><td class="textpublicpayment"><br><strong>'.$langs->trans("WelcomeOnPaymentPage").'</strong><br></td></tr>'."\n";
    $text.='<tr><td class="textpublicpayment"><br>'.$langs->trans("ThisScreenAllowsYouToPay",$creditor).'<br><br></td></tr>'."\n";
}
print $text;

// Output payment summary form
print '<tr><td align="center">';
print '<table with="100%" id="tablepublicpayment">';
print '<tr class="liste_total"><td align="left" colspan="2">'.$langs->trans("ThisIsInformationOnPayment").' :</td></tr>'."\n";

$found=false;
$error=0;
$var=false;

// Free payment
if (! GETPOST("origin"))
{
    $found=true;
    $tag=GETPOST("tag");
    $fulltag=$tag;

    // Creditor
    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("Creditor");
    print '</td><td class="CTableRow'.($var?'1':'2').'"><b>'.$creditor.'</b>';
    print '<input type="hidden" name="creditor" value="'.$creditor.'">';
    print '</td></tr>'."\n";

    // Amount
    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("Amount");
    if (empty($amount)) print ' ('.$langs->trans("ToComplete").')';
    print '</td><td class="CTableRow'.($var?'1':'2').'">';
    if (empty($amount) || ! is_numeric($amount))
    {
        print '<input type="hidden" name="amount" value="'.GETPOST("amount",'int').'">';
        print '<input class="flat" size=8 type="text" name="newamount" value="'.GETPOST("newamount","int").'">';
    }
    else {
        print '<b>'.price($amount).'</b>';
        print '<input type="hidden" name="amount" value="'.$amount.'">';
        print '<input type="hidden" name="newamount" value="'.$amount.'">';
    }
    // Currency
    print ' <b>'.$langs->trans("Currency".$currency).'</b>';
    print '<input type="hidden" name="currency" value="'.$currency.'">';
    print '</td></tr>'."\n";

    // Tag

    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("PaymentCode");
    print '</td><td class="CTableRow'.($var?'1':'2').'"><b>'.$fulltag.'</b>';
    print '<input type="hidden" name="tag" value="'.$tag.'">';
    print '<input type="hidden" name="fulltag" value="'.$fulltag.'">';
    print '</td></tr>'."\n";

    // We do not add fields shipToName, shipToStreet, shipToCity, shipToState, shipToCountryCode, shipToZip, shipToStreet2, phoneNum
    // as they don't exists (buyer is unknown, tag is free).
}


// Payment on customer order
if (GETPOST("origin") == 'order')
{
    $found=true;
    $langs->load("orders");

    require_once DOL_DOCUMENT_ROOT.'/commande/class/commande.class.php';

    $order=new Commande($db);
    $result=$order->fetch('',$ref);
    if ($result < 0)
    {
        $mesg=$order->error;
        $error++;
    }
    else
    {
        $result=$order->fetch_thirdparty($order->socid);
    }

    if ($action != 'stripeSource') // Do not change amount if we just click on first dopayment
    {
        $amount=$order->total_ttc;
        if (GETPOST("amount",'int')) $amount=GETPOST("amount",'int');
        $amount=price2num($amount);
    }

    $fulltag='ORD='.$order->ref.'.CUS='.$order->thirdparty->id;
    //$fulltag.='.NAM='.strtr($order->thirdparty->name,"-"," ");
    if (! empty($TAG)) { $tag=$TAG; $fulltag.='.TAG='.$TAG; }
    $fulltag=dol_string_unaccent($fulltag);

    // Creditor

    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("Creditor");
    print '</td><td class="CTableRow'.($var?'1':'2').'"><b>'.$creditor.'</b>';
    print '<input type="hidden" name="creditor" value="'.$creditor.'">';
    print '</td></tr>'."\n";

    // Debitor

    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("ThirdParty");
    print '</td><td class="CTableRow'.($var?'1':'2').'"><b>'.$order->thirdparty->name.'</b>';

    // Object

    $text='<b>'.$langs->trans("PaymentOrderRef",$order->ref).'</b>';
    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("Designation");
    print '</td><td class="CTableRow'.($var?'1':'2').'">'.$text;
    print '<input type="hidden" name="origin" value="'.GETPOST("origin",'alpha').'">';
    print '<input type="hidden" name="ref" value="'.$order->ref.'">';
    print '</td></tr>'."\n";

    // Amount

    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("Amount");
    if (empty($amount)) print ' ('.$langs->trans("ToComplete").')';
    print '</td><td class="CTableRow'.($var?'1':'2').'">';
    if (empty($amount) || ! is_numeric($amount))
    {
        print '<input type="hidden" name="amount" value="'.GETPOST("amount",'int').'">';
        print '<input class="flat" size=8 type="text" name="newamount" value="'.GETPOST("newamount","int").'">';
    }
    else {
        print '<b>'.price($amount).'</b>';
        print '<input type="hidden" name="amount" value="'.$amount.'">';
        print '<input type="hidden" name="newamount" value="'.$amount.'">';
    }
    // Currency
    print ' <b>'.$langs->trans("Currency".$currency).'</b>';
    print '<input type="hidden" name="currency" value="'.$currency.'">';
    print '</td></tr>'."\n";

    // Tag

    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("PaymentCode");
    print '</td><td class="CTableRow'.($var?'1':'2').'"><b>'.$fulltag.'</b>';
    print '<input type="hidden" name="tag" value="'.$tag.'">';
    print '<input type="hidden" name="fulltag" value="'.$fulltag.'">';
    print '</td></tr>'."\n";

    // Shipping address
    $shipToName=$order->thirdparty->name;
    $shipToStreet=$order->thirdparty->address;
    $shipToCity=$order->thirdparty->town;
    $shipToState=$order->thirdparty->state_code;
    $shipToCountryCode=$order->thirdparty->country_code;
    $shipToZip=$order->thirdparty->zip;
    $shipToStreet2='';
    $phoneNum=$order->thirdparty->phone;
    if ($shipToName && $shipToStreet && $shipToCity && $shipToCountryCode && $shipToZip)
    {
        print '<input type="hidden" name="shipToName" value="'.$shipToName.'">'."\n";
        print '<input type="hidden" name="shipToStreet" value="'.$shipToStreet.'">'."\n";
        print '<input type="hidden" name="shipToCity" value="'.$shipToCity.'">'."\n";
        print '<input type="hidden" name="shipToState" value="'.$shipToState.'">'."\n";
        print '<input type="hidden" name="shipToCountryCode" value="'.$shipToCountryCode.'">'."\n";
        print '<input type="hidden" name="shipToZip" value="'.$shipToZip.'">'."\n";
        print '<input type="hidden" name="shipToStreet2" value="'.$shipToStreet2.'">'."\n";
        print '<input type="hidden" name="phoneNum" value="'.$phoneNum.'">'."\n";
    }
    else
    {
        print '<!-- Shipping address not complete, so we don t use it -->'."\n";
    }
    print '<input type="hidden" name="email" value="'.$order->thirdparty->email.'">'."\n";
    print '<input type="hidden" name="desc" value="'.$langs->trans("Order").' '.$order->ref.'">'."\n";
}


// Payment on customer invoice
if (GETPOST("origin") == 'invoice')
{
    $found=true;
    $langs->load("bills");

    require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php';

    $invoice=new Facture($db);
    $result=$invoice->fetch('',$ref);
    if ($result < 0)
    {
        $mesg=$invoice->error;
        $error++;
    }
    else
    {
        $result=$invoice->fetch_thirdparty($invoice->socid);
    }

    if ($action != 'stripeSource') // Do not change amount if we just click on first dopayment
    {
        $amount=price2num($invoice->total_ttc - $invoice->getSommePaiement());
        if (GETPOST("amount",'int')) $amount=GETPOST("amount",'int');
        $amount=price2num($amount);
    }
    $societe = new Societe($db);
    $societe->fetch($invoice->socid);
    $customerstripe=$stripeconnect->CustomerStripe($invoice->socid,$stripeconnect->GetStripeAccount($conf->entity));
    $fulltag='INV='.$invoice->ref.'.CUS='.$societe->code_client;
    //$fulltag.='.NAM='.strtr($invoice->thirdparty->name,"-"," ");
    if (! empty($TAG)) { $tag=$TAG; $fulltag.='.TAG='.$TAG; }
    $fulltag=dol_string_unaccent($fulltag);

    // Creditor

    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("Creditor");
    print '</td><td class="CTableRow'.($var?'1':'2').'"><b>'.$creditor.'</b>';
    print '<input type="hidden" name="creditor" value="'.$creditor.'">';
    print '</td></tr>'."\n";

    // Debitor
    
    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("ThirdParty");
    print '</td><td class="CTableRow'.($var?'1':'2').'"><b>'.$invoice->thirdparty->name.'</b><input type="hidden" name="customerstripe" value="'.$customerstripe->id.'">';

    // Object

    $text='<b>'.$langs->trans("PaymentInvoiceRef",$invoice->ref).'</b>';
    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("Designation");
    print '</td><td class="CTableRow'.($var?'1':'2').'">'.$text;
    print '<input type="hidden" name="origin" value="'.GETPOST("origin",'alpha').'">';
    print '<input type="hidden" name="ref" value="'.$invoice->ref.'">';
    print '</td></tr>'."\n";

    // Amount

    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("Amount");
    if (empty($amount)) print ' ('.$langs->trans("ToComplete").')';
    print '</td><td class="CTableRow'.($var?'1':'2').'">';
    if (empty($amount) || ! is_numeric($amount))
    {
        print '<input type="hidden" name="amount" value="'.GETPOST("amount",'int').'">';
        print '<input class="flat" size=8 type="text" name="newamount" value="'.GETPOST("newamount","int").'">';
    }
    else {
        print '<b>'.price($amount).'</b>';
        print '<input type="hidden" name="amount" value="'.$amount.'">';
        print '<input type="hidden" name="newamount" value="'.$amount.'">';
    }
    // Currency
    print ' <b>'.$langs->trans("Currency".$currency).'</b>';
    print '<input type="hidden" name="currency" value="'.$currency.'">';
    print '</td></tr>'."\n";

    // Tag

    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("PaymentCode");
    print '</td><td class="CTableRow'.($var?'1':'2').'"><b>'.$fulltag.'</b>';
    print '<input type="hidden" name="tag" value="'.$tag.'">';
    print '<input type="hidden" name="fulltag" value="'.$fulltag.'">';
    print '</td></tr>'."\n";

    // Shipping address
    $shipToName=$invoice->thirdparty->name;
    $shipToStreet=$invoice->thirdparty->address;
    $shipToCity=$invoice->thirdparty->town;
    $shipToState=$invoice->thirdparty->state_code;
    $shipToCountryCode=$invoice->thirdparty->country_code;
    $shipToZip=$invoice->thirdparty->zip;
    $shipToStreet2='';
    $phoneNum=$invoice->thirdparty->phone;
    if ($shipToName && $shipToStreet && $shipToCity && $shipToCountryCode && $shipToZip)
    {
        print '<input type="hidden" name="shipToName" value="'.$shipToName.'">'."\n";
        print '<input type="hidden" name="shipToStreet" value="'.$shipToStreet.'">'."\n";
        print '<input type="hidden" name="shipToCity" value="'.$shipToCity.'">'."\n";
        print '<input type="hidden" name="shipToState" value="'.$shipToState.'">'."\n";
        print '<input type="hidden" name="shipToCountryCode" value="'.$shipToCountryCode.'">'."\n";
        print '<input type="hidden" name="shipToZip" value="'.$shipToZip.'">'."\n";
        print '<input type="hidden" name="shipToStreet2" value="'.$shipToStreet2.'">'."\n";
        print '<input type="hidden" name="phoneNum" value="'.$phoneNum.'">'."\n";
    }
    else
    {
        print '<!-- Shipping address not complete, so we don t use it -->'."\n";
    }
    print '<input type="hidden" name="email" value="'.$invoice->thirdparty->email.'">'."\n";
    print '<input type="hidden" name="desc" value="'.$langs->trans("Invoice").' '.$invoice->ref.'">'."\n";
}

// Payment on contract line
if (GETPOST("origin") == 'contractline')
{
    $found=true;
    $langs->load("contracts");

    require_once DOL_DOCUMENT_ROOT.'/contrat/class/contrat.class.php';

    $contractline=new ContratLigne($db);
    $result=$contractline->fetch('',$ref);
    if ($result < 0)
    {
        $mesg=$contractline->error;
        $error++;
    }
    else
    {
        if ($contractline->fk_contrat > 0)
        {
            $contract=new Contrat($db);
            $result=$contract->fetch($contractline->fk_contrat);
            if ($result > 0)
            {
                $result=$contract->fetch_thirdparty($contract->socid);
            }
            else
            {
                $mesg=$contract->error;
                $error++;
            }
        }
        else
        {
            $mesg='ErrorRecordNotFound';
            $error++;
        }
    }

    if ($action != 'stripeSource') // Do not change amount if we just click on first dopayment
    {
        $amount=$contractline->total_ttc;
        if ($contractline->fk_product)
        {
            $product=new Product($db);
            $result=$product->fetch($contractline->fk_product);

            // We define price for product (TODO Put this in a method in product class)
            if (! empty($conf->global->PRODUIT_MULTIPRICES))
            {
                $pu_ht = $product->multiprices[$contract->thirdparty->price_level];
                $pu_ttc = $product->multiprices_ttc[$contract->thirdparty->price_level];
                $price_base_type = $product->multiprices_base_type[$contract->thirdparty->price_level];
            }
            else
            {
                $pu_ht = $product->price;
                $pu_ttc = $product->price_ttc;
                $price_base_type = $product->price_base_type;
            }

            $amount=$pu_ttc;
            if (empty($amount))
            {
                dol_print_error('','ErrorNoPriceDefinedForThisProduct');
                exit;
            }
        }

        if (GETPOST("amount",'int')) $amount=GETPOST("amount",'int');
        $amount=price2num($amount);
    }

    $fulltag='COL='.$contractline->ref.'.CON='.$contract->ref.'.CUS='.$contract->thirdparty->id.'.DAT='.dol_print_date(dol_now(),'%Y%m%d%H%M');
    //$fulltag.='.NAM='.strtr($contract->thirdparty->name,"-"," ");
    if (! empty($TAG)) { $tag=$TAG; $fulltag.='.TAG='.$TAG; }
    $fulltag=dol_string_unaccent($fulltag);

    $qty=1;
    if (GETPOST('qty')) $qty=GETPOST('qty');

    // Creditor

    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("Creditor");
    print '</td><td class="CTableRow'.($var?'1':'2').'"><b>'.$creditor.'</b>';
    print '<input type="hidden" name="creditor" value="'.$creditor.'">';
    print '</td></tr>'."\n";

    // Debitor

    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("ThirdParty");
    print '</td><td class="CTableRow'.($var?'1':'2').'"><b>'.$contract->thirdparty->name.'</b>';

    // Object

    $text='<b>'.$langs->trans("PaymentRenewContractId",$contract->ref,$contractline->ref).'</b>';
    if ($contractline->fk_product)
    {
        $text.='<br>'.$product->ref.($product->label?' - '.$product->label:'');
    }
    if ($contractline->description) $text.='<br>'.dol_htmlentitiesbr($contractline->description);
    //if ($contractline->date_fin_validite) {
    //	$text.='<br>'.$langs->trans("DateEndPlanned").': ';
    //	$text.=dol_print_date($contractline->date_fin_validite);
    //}
    if ($contractline->date_fin_validite)
    {
        $text.='<br>'.$langs->trans("ExpiredSince").': '.dol_print_date($contractline->date_fin_validite);
    }

    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("Designation");
    print '</td><td class="CTableRow'.($var?'1':'2').'">'.$text;
    print '<input type="hidden" name="origin" value="'.GETPOST("origin",'alpha').'">';
    print '<input type="hidden" name="ref" value="'.$contractline->ref.'">';
    print '</td></tr>'."\n";

    // Quantity

    $label=$langs->trans("Quantity");
    $qty=1;
    $duration='';
    if ($contractline->fk_product)
    {
        if ($product->isService() && $product->duration_value > 0)
        {
            $label=$langs->trans("Duration");

            // TODO Put this in a global method
            if ($product->duration_value > 1)
            {
                $dur=array("h"=>$langs->trans("Hours"),"d"=>$langs->trans("DurationDays"),"w"=>$langs->trans("DurationWeeks"),"m"=>$langs->trans("DurationMonths"),"y"=>$langs->trans("DurationYears"));
            }
            else
            {
                $dur=array("h"=>$langs->trans("Hour"),"d"=>$langs->trans("DurationDay"),"w"=>$langs->trans("DurationWeek"),"m"=>$langs->trans("DurationMonth"),"y"=>$langs->trans("DurationYear"));
            }
            $duration=$product->duration_value.' '.$dur[$product->duration_unit];
        }
    }
    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$label.'</td>';
    print '<td class="CTableRow'.($var?'1':'2').'"><b>'.($duration?$duration:$qty).'</b>';
    print '<input type="hidden" name="newqty" value="'.dol_escape_htmltag($qty).'">';
    print '</b></td></tr>'."\n";

    // Amount

    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("Amount");
    if (empty($amount)) print ' ('.$langs->trans("ToComplete").')';
    print '</td><td class="CTableRow'.($var?'1':'2').'">';
    if (empty($amount) || ! is_numeric($amount))
    {
        print '<input type="hidden" name="amount" value="'.GETPOST("amount",'int').'">';
        print '<input class="flat" size=8 type="text" name="newamount" value="'.GETPOST("newamount","int").'">';
    }
    else {
        print '<b>'.price($amount).'</b>';
        print '<input type="hidden" name="amount" value="'.$amount.'">';
        print '<input type="hidden" name="newamount" value="'.$amount.'">';
    }
    // Currency
    print ' <b>'.$langs->trans("Currency".$currency).'</b>';
    print '<input type="hidden" name="currency" value="'.$currency.'">';
    print '</td></tr>'."\n";

    // Tag

    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("PaymentCode");
    print '</td><td class="CTableRow'.($var?'1':'2').'"><b>'.$fulltag.'</b>';
    print '<input type="hidden" name="tag" value="'.$tag.'">';
    print '<input type="hidden" name="fulltag" value="'.$fulltag.'">';
    print '</td></tr>'."\n";

    // Shipping address
    $shipToName=$contract->thirdparty->name;
    $shipToStreet=$contract->thirdparty->address;
    $shipToCity=$contract->thirdparty->town;
    $shipToState=$contract->thirdparty->state_code;
    $shipToCountryCode=$contract->thirdparty->country_code;
    $shipToZip=$contract->thirdparty->zip;
    $shipToStreet2='';
    $phoneNum=$contract->thirdparty->phone;
    if ($shipToName && $shipToStreet && $shipToCity && $shipToCountryCode && $shipToZip)
    {
        print '<input type="hidden" name="shipToName" value="'.$shipToName.'">'."\n";
        print '<input type="hidden" name="shipToStreet" value="'.$shipToStreet.'">'."\n";
        print '<input type="hidden" name="shipToCity" value="'.$shipToCity.'">'."\n";
        print '<input type="hidden" name="shipToState" value="'.$shipToState.'">'."\n";
        print '<input type="hidden" name="shipToCountryCode" value="'.$shipToCountryCode.'">'."\n";
        print '<input type="hidden" name="shipToZip" value="'.$shipToZip.'">'."\n";
        print '<input type="hidden" name="shipToStreet2" value="'.$shipToStreet2.'">'."\n";
        print '<input type="hidden" name="phoneNum" value="'.$phoneNum.'">'."\n";
    }
    else
    {
        print '<!-- Shipping address not complete, so we don t use it -->'."\n";
    }
    print '<input type="hidden" name="email" value="'.$contract->thirdparty->email.'">'."\n";
    print '<input type="hidden" name="desc" value="'.$langs->trans("Contract").' '.$contract->ref.'">'."\n";
}

// Payment on member subscription
if (GETPOST("origin") == 'membersubscription')
{
    $found=true;
    $langs->load("members");

    require_once DOL_DOCUMENT_ROOT.'/adherents/class/adherent.class.php';
    require_once DOL_DOCUMENT_ROOT.'/adherents/class/subscription.class.php';

    $member=new Adherent($db);
    $result=$member->fetch('',$ref);
    if ($result < 0)
    {
        $mesg=$member->error;
        $error++;
    }
    else
    {
        $subscription=new Subscription($db);
    }

    if ($action != 'stripeSource') // Do not change amount if we just click on first dopayment
    {
        $amount=$subscription->total_ttc;
        if (GETPOST("amount",'int')) $amount=GETPOST("amount",'int');
        $amount=price2num($amount);
    }

    $fulltag='MEM='.$member->id.'.DAT='.dol_print_date(dol_now(),'%Y%m%d%H%M');
    if (! empty($TAG)) { $tag=$TAG; $fulltag.='.TAG='.$TAG; }
    $fulltag=dol_string_unaccent($fulltag);

    // Creditor

    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("Creditor");
    print '</td><td class="CTableRow'.($var?'1':'2').'"><b>'.$creditor.'</b>';
    print '<input type="hidden" name="creditor" value="'.$creditor.'">';
    print '</td></tr>'."\n";

    // Debitor

    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("Member");
    print '</td><td class="CTableRow'.($var?'1':'2').'"><b>';
    if ($member->morphy == 'mor' && ! empty($member->societe)) print $member->societe;
    else print $member->getFullName($langs);
    print '</b>';

    // Object

    $text='<b>'.$langs->trans("PaymentSubscription").'</b>';
    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("Designation");
    print '</td><td class="CTableRow'.($var?'1':'2').'">'.$text;
    print '<input type="hidden" name="origin" value="'.GETPOST("origin",'alpha').'">';
    print '<input type="hidden" name="ref" value="'.$member->ref.'">';
    print '</td></tr>'."\n";

    if ($member->last_subscription_date || $member->last_subscription_amount)
    {
        // Last subscription date

        print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("LastSubscriptionDate");
        print '</td><td class="CTableRow'.($var?'1':'2').'">'.dol_print_date($member->last_subscription_date,'day');
        print '</td></tr>'."\n";

        // Last subscription amount

        print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("LastSubscriptionAmount");
        print '</td><td class="CTableRow'.($var?'1':'2').'">'.price($member->last_subscription_amount);
        print '</td></tr>'."\n";

        if (empty($amount) && ! GETPOST('newamount')) $_GET['newamount']=$member->last_subscription_amount;
    }

    // Amount

    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("Amount");
    if (empty($amount))
    {
        print ' ('.$langs->trans("ToComplete");
        if (! empty($conf->global->MEMBER_EXT_URL_SUBSCRIPTION_INFO)) print ' - <a href="'.$conf->global->MEMBER_EXT_URL_SUBSCRIPTION_INFO.'" rel="external" target="_blank">'.$langs->trans("SeeHere").'</a>';
        print ')';
    }
    print '</td><td class="CTableRow'.($var?'1':'2').'">';
    if (empty($amount) || ! is_numeric($amount))
    {
        $valtoshow=GETPOST("newamount",'int');
        if (! empty($conf->global->MEMBER_MIN_AMOUNT) && $valtoshow) $valtoshow=max($conf->global->MEMBER_MIN_AMOUNT,$valtoshow);
        print '<input type="hidden" name="amount" value="'.GETPOST("amount",'int').'">';
        print '<input class="flat" size="8" type="text" name="newamount" value="'.$valtoshow.'">';
    }
    else {
        $valtoshow=$amount;
        if (! empty($conf->global->MEMBER_MIN_AMOUNT) && $valtoshow) $valtoshow=max($conf->global->MEMBER_MIN_AMOUNT,$valtoshow);
        print '<b>'.price($valtoshow).'</b>';
        print '<input type="hidden" name="amount" value="'.$valtoshow.'">';
        print '<input type="hidden" name="newamount" value="'.$valtoshow.'">';
    }
    // Currency
    print ' <b>'.$langs->trans("Currency".$currency).'</b>';
    print '<input type="hidden" name="currency" value="'.$currency.'">';
    print '</td></tr>'."\n";

    // Tag

    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'">'.$langs->trans("PaymentCode");
    print '</td><td class="CTableRow'.($var?'1':'2').'"><b>'.$fulltag.'</b>';
    print '<input type="hidden" name="tag" value="'.$tag.'">';
    print '<input type="hidden" name="fulltag" value="'.$fulltag.'">';
    print '</td></tr>'."\n";

    // Shipping address
    $shipToName=$member->getFullName($langs);
    $shipToStreet=$member->address;
    $shipToCity=$member->town;
    $shipToState=$member->state_code;
    $shipToCountryCode=$member->country_code;
    $shipToZip=$member->zip;
    $shipToStreet2='';
    $phoneNum=$member->phone;
    if ($shipToName && $shipToStreet && $shipToCity && $shipToCountryCode && $shipToZip)
    {
        print '<input type="hidden" name="shipToName" value="'.$shipToName.'">'."\n";
        print '<input type="hidden" name="shipToStreet" value="'.$shipToStreet.'">'."\n";
        print '<input type="hidden" name="shipToCity" value="'.$shipToCity.'">'."\n";
        print '<input type="hidden" name="shipToState" value="'.$shipToState.'">'."\n";
        print '<input type="hidden" name="shipToCountryCode" value="'.$shipToCountryCode.'">'."\n";
        print '<input type="hidden" name="shipToZip" value="'.$shipToZip.'">'."\n";
        print '<input type="hidden" name="shipToStreet2" value="'.$shipToStreet2.'">'."\n";
        print '<input type="hidden" name="phoneNum" value="'.$phoneNum.'">'."\n";
    }
    else
    {
        print '<!-- Shipping address not complete, so we don t use it -->'."\n";
    }
    print '<input type="hidden" name="email" value="'.$member->email.'">'."\n";
    print '<input type="hidden" name="desc" value="'.$langs->trans("PaymentSubscription").'">'."\n";
}
if ($mesg) print '<tr><td align="center" colspan="2"><br><div class="warning">'.$mesg.'</div></td></tr>'."\n";

print '</table>'."\n";
print "<br>\n";

if (! $found && ! $mesg) $mesg=$langs->trans("ErrorBadParameters");

if ($validation) {
if ($validation==ok) {
print "</form>";
print "<span class='fa fa-check-circle fa-5x fa-fw text-danger'></span> ".$langs->transnoentitiesnoconv("NewOnlinePaymentReceived");

}elseif ($validation==ko) {
print "</form>";
print "<span class='fa fa-exclamation-circle fa-5x fa-fw text-danger'></span> ".$langs->transnoentitiesnoconv("NewStripePaymentFailed");

}
} else {

print '<table id="dolpaymenttable" summary="Payment form" with="100%">'."\n";
$cu = \Stripe\Customer::retrieve("".$customerstripe->id."",array("stripe_account" => $stripeconnect->GetStripeAccount($conf->entity)));
$input=$cu->sources->data;
    foreach ($input as $src) {
print '<tr '.$bc[0].'>';

            print '<td align="center" width="20" ><input type="radio" id="source_id" class="flat" name="stripeSource" onclick="this.form.submit();" value="'.$src->id.'"';
//if ($action != 'stripeSource')
//{print ' disabled';}
if (($cu->default_source==$src->id && $action != 'add_paiement') or (GETPOST("stripeSource",'alpha')==$src->id)) {
                print ' checked';
            }
            print '></td>';

print '<td align="center">';
if ($src->object=='card'){
if ($src->brand == 'Visa') {$brand='cc-visa';}
elseif ($src->brand == 'MasterCard') {$brand='cc-mastercard';}
elseif ($src->brand == 'American Express') {$brand='cc-amex';}
elseif ($src->brand == 'Discover') {$brand='cc-discover';}
elseif ($src->brand == 'JCB') {$brand='cc-jcb';}
elseif ($src->brand == 'Diners Club') {$brand='cc-diners-club';}
else {$brand='credit-card-alt';}
print '<span class="fa fa-'.$brand.' fa-3x fa-fw"></span>';
}
elseif ($src->object=='source' && $src->type=='card'){
if ($src->card->brand == 'Visa') {$brand='cc-visa';}
elseif ($src->card->brand == 'MasterCard') {$brand='cc-mastercard';}
elseif ($src->card->brand == 'American Express') {$brand='cc-amex';}
elseif ($src->card->brand == 'Discover') {$brand='cc-discover';}
elseif ($src->card->brand == 'JCB') {$brand='cc-jcb';}
elseif ($src->card->brand == 'Diners Club') {$brand='cc-diners-club';}
else {$brand='credit-card-alt';}

print '<span class="fa fa-'.$brand.' fa-3x fa-fw"></span>';
}
elseif ($src->object=='source' && $src->type=='sepa_debit'){
print '<span class="fa fa-university fa-3x fa-fw"></span>';
}
print '</td>';
print '<td >';
if ($src->object=='card'){
print '**** '.$src->last4.'<br>Exp. '.$src->exp_month.'/'.$src->exp_year.'';
print '</td><td>';
 if ($src->country)
	{
		$img=picto_from_langcode($src->country);
		print $img?$img.' ':'';
		print getCountry($src->country,1);
	}
	else print img_warning().' <font class="error">'.$langs->trans("ErrorFieldRequired",$langs->transnoentitiesnoconv("CompanyCountry")).'</font>';
}
elseif ($src->object=='source' && $src->type=='card'){
print '**** '.$src->card->last4.'<br>Exp. '.$src->card->exp_month.'/'.$src->card->exp_year.'';
print '</td><td>';
 if ($src->card->country)
	{
		$img=picto_from_langcode($src->card->country);
		print $img?$img.' ':'';
		print getCountry($src->card->country,1);
	}
	else print img_warning().' <font class="error">'.$langs->trans("ErrorFieldRequired",$langs->transnoentitiesnoconv("CompanyCountry")).'</font>';
}
elseif ($src->object=='source' && $src->type=='sepa_debit'){
print 'info sepa';
print '</td><td>';
 if ($src->sepa_debit->country)
	{
		$img=picto_from_langcode($src->sepa_debit->country);
		print $img?$img.' ':'';
		print getCountry($src->sepa_debit->country,1);
	}
	else print img_warning().' <font class="error">'.$langs->trans("ErrorFieldRequired",$langs->transnoentitiesnoconv("CompanyCountry")).'</font>';
}
print '</td><td align="center">';
           		print '<a href="'.$url.'&source='.$src->id.'&customer='.$customerstripe->id.'&action=delete">';
           		print img_picto($langs->trans("Delete"),'delete');
           		print '</a>';
            print '</td>';
print '</tr><input type="hidden" name"save_source" value"0">';
}
if (count($input)<11) {
print '<tr '.$bc[0].'><td align="center" width="20" ><input id="rNo" type="radio" name="stripeSource" value="src_newcard" onclick="this.form.submit();"';
//if ($action != 'stripeSource')
//{print ' disabled';}
if (GETPOST("stripeSource",'alpha')=='src_newcard' or empty($input)) {print ' checked';}
print '></td><td align="center"><span class="fa fa-credit-card-alt fa-3x fa-fw"></span></td><td colspan="3"> Payer avec une nouvelle carte</td></tr>'."\n";
}
print '</table>'."\n";
if ($action != 'stripeSource')
{
    if ($found && ! $error)	// We are in a management option and no error
    {
        print '<br><input class="button" type="submit" name="stripeSource_stripe" value="'.$langs->trans("StripeDoPayment").'">';
    }
    else
    {
        dol_print_error_email('ERRORNEWPAYMENTSTRIPE');
    }
}


print '</td></tr>'."\n";


print '</form>'."\n";
print '</div>'."\n";
print '<form action="'.$_SERVER['REQUEST_URI'].'" method="POST" id="payment-form">';
// Add more content on page for some services
if ((preg_match('/^stripeSource/',$action)&&(GETPOST("stripeSource",'alpha')=='src_newcard')) or (preg_match('/^stripeSource/',$action)&&empty($input)))
{

    print '<style>
    /**
     * The CSS shown here will not be introduced in the Quickstart guide, but shows
     * how you can use CSS to style your Element s container.
     */
    .StripeElement {
        background-color: white;
        padding: 8px 12px;
        border-radius: 4px;
        border: 1px solid transparent;
        box-shadow: 0 1px 3px 0 #e6ebf1;
        -webkit-transition: box-shadow 150ms ease;
        transition: box-shadow 150ms ease;
    }

    .StripeElement--focus {
        box-shadow: 0 1px 3px 0 #cfd7df;
    }

    .StripeElement--invalid {
        border-color: #fa755a;
    }

    .StripeElement--webkit-autofill {
        background-color: #fefde5 !important;
    }
    </style>';

    print '<input type="hidden" name="token" value="'.$_SESSION['newtoken'].'">'."\n";
    print '<input type="hidden" name="save_source" value="1">'."\n";
    print '<input type="hidden" name="action" value="charge">'."\n";
    print '<input type="hidden" name="tag" value="'.$TAG.'">'."\n";
    print '<input type="hidden" name="origin" value="'.$ORIGIN.'">'."\n";
    print '<input type="hidden" name="ref" value="'.$REF.'">'."\n";
    print '<input type="hidden" name="customerstripe" value="'.$CUSTOMERSTRIPE.'">'."\n";
    print '<input type="hidden" name="fulltag" value="'.$FULLTAG.'">'."\n";
    print '<input type="hidden" name="suffix" value="'.$suffix.'">'."\n";
    print '<input type="hidden" name="securekey" value="'.$SECUREKEY.'">'."\n";
    print '<input type="hidden" name="entity" value="'.$entity.'" />';
    print '<input type="hidden" name="amount" value="'.$amount.'">'."\n";
    print '<input type="hidden" name="currency" value="'.$currency.'">'."\n";

    print '<table id="dolpaymenttable" summary="Payment form" class="center">
    <tbody><tr><td class="textpublicpayment">

    <div class="form-row left">
    <label for="card-element">
    Merci de saisir vos informations bancaires
    </label>
    <div id="card-element">
    <!-- a Stripe Element will be inserted here. -->
    </div>

    <!-- Used to display form errors -->
    <div id="card-errors" role="alert"></div>
    </div>

    <script src="https://js.stripe.com/v2/"></script>
    <script src="https://js.stripe.com/v3/"></script>

    <script type="text/javascript" language="javascript">';
    ?>
  
    // Create a Stripe client
    var stripe = Stripe('<?php echo $stripe['publishable_key']; ?>');

    // Create an instance of Elements
    var elements = stripe.elements();

    // Custom styling can be passed to options when creating an Element.
    // (Note that this demo uses a wider set of styles than the guide below.)
    var style = {
      base: {
        color: '#32325d',
        lineHeight: '24px',
        fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
        fontSmoothing: 'antialiased',
        fontSize: '16px',
        '::placeholder': {
          color: '#aab7c4'
        }
      },
      invalid: {
        color: '#fa755a',
        iconColor: '#fa755a'
      }
    };

    // Create an instance of the card Element
    var card = elements.create('card', {style: style});

    // Add an instance of the card Element into the `card-element` <div>
    card.mount('#card-element');

    // Handle real-time validation errors from the card Element.
    card.addEventListener('change', function(event) {
      var displayError = document.getElementById('card-errors');
      if (event.error) {
        displayError.textContent = event.error.message;
      } else {
        displayError.textContent = '';
      }
    });
    
    // Handle form submission   
   var form = document.getElementById('payment-form');
form.addEventListener('submit', function(event) {
  event.preventDefault();

  stripe.createSource(card).then(function(result) {
    if (result.error) {
      // Inform the user if there was an error
      var errorElement = document.getElementById('card-errors');
      errorElement.textContent = result.error.message;
    } else {
      // Send the source to your server
      stripeSourceHandler(result.source);
    }
  });
});


function stripeSourceHandler(source) {
  // Insert the source ID into the form so it gets submitted to the server
  var form = document.getElementById('payment-form');
  var hiddenInput = document.createElement('input');
  hiddenInput.setAttribute('type', 'hidden');
  hiddenInput.setAttribute('name', 'stripeSource');
  hiddenInput.setAttribute('value', source.id);
  form.appendChild(hiddenInput);

      // Submit the form
      jQuery('#buttontopay').hide();
      jQuery('#hourglasstopay').show();
      console.log("submit");
      form.submit();
    }

    <?php
    print '</script></tr></td></table>';
}
else {
    print '<script type="text/javascript" language="javascript">';
?>

      // Submit the form
      jQuery('#buttontopay').hide();
      jQuery('#hourglasstopay').show();
      console.log("submit");
      form.submit();


    <?php
    print '</script>';
}
if (preg_match('/^stripeSource/',$action)&&(GETPOST("stripeSource",'alpha')!='src_newcard'))
{
    print '<input type="hidden" name="token" value="'.$_SESSION['newtoken'].'">'."\n";
    print '<input type="hidden" name="stripeSource" value="'.GETPOST("stripeSource",'alpha').'">'."\n";
    print '<input type="hidden" name="action" value="charge">'."\n";
    print '<input type="hidden" name="tag" value="'.$TAG.'">'."\n";
    print '<input type="hidden" name="origin" value="'.$ORIGIN.'">'."\n";
    print '<input type="hidden" name="ref" value="'.$REF.'">'."\n";
    print '<input type="hidden" name="customerstripe" value="'.$CUSTOMERSTRIPE.'">'."\n";
    print '<input type="hidden" name="fulltag" value="'.$FULLTAG.'">'."\n";
    print '<input type="hidden" name="suffix" value="'.$suffix.'">'."\n";
    print '<input type="hidden" name="securekey" value="'.$SECUREKEY.'">'."\n";
    print '<input type="hidden" name="entity" value="'.$entity.'" />';
    print '<input type="hidden" name="amount" value="'.$amount.'">'."\n";
    print '<input type="hidden" name="currency" value="'.$currency.'">'."\n";
}
if ($action == 'stripeSource'){
    if ($found && ! $error)	// We are in a management option and no error
    {
    print '<tr class="CTableRow'.($var?'1':'2').'"><td class="CTableRow'.($var?'1':'2').'" colspan="2"><br>
    <button class="button" id="buttontopay">'.$langs->trans("ToMakePayment").'</button>
   <div id="hourglasstopay" class="hidden"><i class="fa fa-spinner fa-spin fa-4x fa-fw"></i></div>';
    }
    else
    {
        dol_print_error_email('ERRORNEWPAYMENTSTRIPE');
    }
}   
  print '</form>';
}
 
print '</table>'."\n";

htmlPrintOnlinePaymentFooter($mysoc,$langs);

llxFooter('', 'public');

$db->close();

