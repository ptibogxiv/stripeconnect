<?php
/* Copyright (C) 2017		Alexandre Spangaro		<aspangaro@zendsi.com>
 * Copyright (C) 2017		Olivier Geffroy			<jeff@jeffinfo.com>
 * Copyright (C) 2017		Saasprov				<saasprov@gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * \file       htdocs/stripe/admin/stripe.php
 * \ingroup    stripe
 * \brief      Page to setup stripe module
 */

require '../../../main.inc.php';
dol_include_once('/stripeconnect/lib/stripeconnect.lib.php');
require_once DOL_DOCUMENT_ROOT.'/core/lib/admin.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/doleditor.class.php';

$servicename='StripeConnect';

$langs->load("admin");
$langs->load("other");
$langs->load("paypal");
$langs->load("paybox");
$langs->load("stripe");
$langs->load("stripeconnect@stripeconnect");

if (! $user->admin) accessforbidden();
  
$action = GETPOST('action','alpha');


if ($action == 'setvalue' && $user->admin)
{
	$db->begin();

    $result=dolibarr_set_const($db, "STRIPECONNECT_LIVE",GETPOST('STRIPECONNECT_LIVE','alpha'),'chaine',0,'',0);
    if (! $result > 0) $error++;
	$result=dolibarr_set_const($db, "STRIPE_TEST_PUBLISHABLE_KEY",GETPOST('STRIPE_TEST_PUBLISHABLE_KEY','alpha'),'chaine',0,'',0);
	if (! $result > 0) $error++;
	$result=dolibarr_set_const($db, "STRIPE_TEST_SECRET_KEY",GETPOST('STRIPE_TEST_SECRET_KEY','alpha'),'chaine',0,'',1);
	if (! $result > 0) $error++;
	$result=dolibarr_set_const($db, "STRIPE_LIVE_PUBLISHABLE_KEY",GETPOST('STRIPE_LIVE_PUBLISHABLE_KEY','alpha'),'chaine',0,'',0);
	if (! $result > 0) $error++;
	$result=dolibarr_set_const($db, "STRIPE_LIVE_SECRET_KEY",GETPOST('STRIPE_LIVE_SECRET_KEY','alpha'),'chaine',0,'',1);
	if (! $result > 0) $error++;
  	$result=dolibarr_set_const($db, "STRIPE_TEST_WEBHOOK_KEY",GETPOST('STRIPE_TEST_WEBHOOK_KEY','alpha'),'chaine',0,'',0);
	if (! $result > 0) $error++;
	$result=dolibarr_set_const($db, "STRIPE_TEST_WEBHOOK_CONNECT_KEY",GETPOST('STRIPE_TEST_WEBHOOK_CONNECT_KEY','alpha'),'chaine',0,'',0);
	if (! $result > 0) $error++;
	$result=dolibarr_set_const($db, "STRIPE_LIVE_WEBHOOK_KEY",GETPOST('STRIPE_LIVE_WEBHOOK_KEY','alpha'),'chaine',0,'',0);
	if (! $result > 0) $error++;
	$result=dolibarr_set_const($db, "STRIPE_LIVE_WEBHOOK_CONNECT_KEY",GETPOST('STRIPE_LIVE_WEBHOOK_CONNECT_KEY','alpha'),'chaine',0,'',0);
	if (! $result > 0) $error++;
	$result=dolibarr_set_const($db, "STRIPE_APPLICATION_FEE_PERCENT",price2num(GETPOST('STRIPE_APPLICATION_FEE_PERCENT','alpha')),'chaine',0,'',0);
  	if (! $result > 0) $error++;
	$result=dolibarr_set_const($db, "STRIPE_APPLICATION_FEE",price2num(GETPOST('STRIPE_APPLICATION_FEE','alpha')),'chaine',0,'',0);
    	if (! $result > 0) $error++;
  $result=dolibarr_set_const($db, "STRIPE_APPLICATION_FEE_MINIMAL",price2num(GETPOST('STRIPE_APPLICATION_FEE_MINIMAL','alpha')),'chaine',0,'',0);
    if (! $result > 0) $error++;
	$result=dolibarr_set_const($db, "STRIPE_APPLICATION_MENSUAL_MINIMAL",price2num(GETPOST('STRIPE_APPLICATION_MENSUAL_MINIMAL','alpha')),'chaine',0,'',0);
    if (! $result > 0) $error++;
    	$result=dolibarr_set_const($db, "STRIPE_APPLICATION_FEE_PRODUCT_ID",GETPOST('STRIPE_APPLICATION_FEE_PRODUCT_ID','alpha'),'chaine',0,'',0);
    if (! $result > 0) $error++;
	
    if (! $error)
  	{
  		$db->commit();
	    setEventMessages($langs->trans("SetupSaved"), null, 'mesgs');
  	}
  	else
  	{
  		$db->rollback();
		dol_print_error($db);
    }
}

if ($action=="setlive")
{
	$liveenable = GETPOST('value','int');
	$res = dolibarr_set_const($db, "STRIPECONNECT_LIVE", $liveenable,'yesno',0,'',0);
	if (! $res > 0) $error++;
	if (! $error)
	{
		setEventMessages($langs->trans("SetupSaved"), null, 'mesgs');
	}
	else
	{
		setEventMessages($langs->trans("Error"), null, 'errors');
	}
}


/*
 *	View
 */

$form=new Form($db);

llxHeader('',$langs->trans("StripeConnectSetup"));

$linkback='<a href="'.DOL_URL_ROOT.'/admin/modules.php">'.$langs->trans("BackToModuleList").'</a>';
print load_fiche_titre($langs->trans("ModuleSetup").' StripeConnect',$linkback);

$head=stripeconnectadmin_prepare_head();

print '<form method="post" action="'.$_SERVER["PHP_SELF"].'">';
print '<input type="hidden" name="token" value="'.$_SESSION['newtoken'].'">';
print '<input type="hidden" name="action" value="setvalue">';

dol_fiche_head($head, 'stripeaccount', '', -1);

print $langs->trans("Module431320Desc")."<br>\n";

print '<br>';

print '<table class="noborder" width="100%">';
print '<tr class="liste_titre">';
print '<td>'.$langs->trans("AccountParameter").'</td>';
print '<td>'.$langs->trans("Value").'</td>';
print "</tr>\n";

print '<tr class="oddeven">';
print '<td class="titlefield">';
print $langs->trans("StripeConnectLiveEnabled").'</td><td>';
if (!empty($conf->global->STRIPECONNECT_LIVE))
{
	print '<a href="'.$_SERVER['PHP_SELF'].'?action=setlive&value=0">';
	print img_picto($langs->trans("Activated"),'switch_on');
}
else
{
	print '<a href="'.$_SERVER['PHP_SELF'].'?action=setlive&value=1">';
	print img_picto($langs->trans("Disabled"),'switch_off');
}
print '</td></tr>';

print '<tr class="oddeven"><td>';
print '<span class="fieldrequired">'.$langs->trans("STRIPE_TEST_PUBLISHABLE_KEY").'</span></td><td>';
print '<input class="minwidth500" type="text" name="STRIPE_TEST_PUBLISHABLE_KEY" value="'.$conf->global->STRIPE_TEST_PUBLISHABLE_KEY.'">';
print ' &nbsp; '.$langs->trans("Example").': pk_test_xxxxxxxxxxxxxxxxxxxxxxxx';
print '</td></tr>';

print '<tr class="oddeven"><td>';
print '<span class="titlefield fieldrequired">'.$langs->trans("STRIPE_TEST_SECRET_KEY").'</span></td><td>';
print '<input class="minwidth300" type="text" name="STRIPE_TEST_SECRET_KEY" value="'.$conf->global->STRIPE_TEST_SECRET_KEY.'">';
print ' &nbsp; '.$langs->trans("Example").': sk_test_xxxxxxxxxxxxxxxxxxxxxxxx';
print '</td></tr>';

print '<tr class="oddeven"><td>';
print '<span class="fieldrequired">'.$langs->trans("STRIPE_LIVE_PUBLISHABLE_KEY").'</span></td><td>';
print '<input class="minwidth300" type="text" name="STRIPE_LIVE_PUBLISHABLE_KEY" value="'.$conf->global->STRIPE_LIVE_PUBLISHABLE_KEY.'">';
print ' &nbsp; '.$langs->trans("Example").': pk_live_xxxxxxxxxxxxxxxxxxxxxxxx';
print '</td></tr>';

print '<tr class="oddeven"><td>';
print '<span class="fieldrequired">'.$langs->trans("STRIPE_LIVE_SECRET_KEY").'</span></td><td>';
print '<input class="minwidth300" type="text" name="STRIPE_LIVE_SECRET_KEY" value="'.$conf->global->STRIPE_LIVE_SECRET_KEY.'">';
print ' &nbsp; '.$langs->trans("Example").': sk_live_xxxxxxxxxxxxxxxxxxxxxxxx';
print '</td></tr>';

print '<tr class="oddeven"><td>';
print '<span class="fieldrequired">'.$langs->trans("STRIPE_TEST_WEBHOOK_KEY").'</span></td><td>';
print '<input class="minwidth300" type="text" name="STRIPE_TEST_WEBHOOK_KEY" value="'.$conf->global->STRIPE_TEST_WEBHOOK_KEY.'">';
print ' &nbsp; '.$langs->trans("Example").': whsec_xxxxxxxxxxxxxxxxxxxxxxxx';
print '</td></tr>';

print '<tr class="oddeven"><td>';
print '<span class="fieldrequired">'.$langs->trans("STRIPE_TEST_WEBHOOK_CONNECT_KEY").'</span></td><td>';
print '<input class="minwidth300" type="text" name="STRIPE_TEST_WEBHOOK_CONNECT_KEY" value="'.$conf->global->STRIPE_TEST_WEBHOOK_CONNECT_KEY.'">';
print ' &nbsp; '.$langs->trans("Example").': whsec_xxxxxxxxxxxxxxxxxxxxxxxx';
print '</td></tr>';

print '<tr class="oddeven"><td>';
print '<span class="fieldrequired">'.$langs->trans("STRIPE_LIVE_WEBHOOK_KEY").'</span></td><td>';
print '<input class="minwidth300" type="text" name="STRIPE_LIVE_WEBHOOK_KEY" value="'.$conf->global->STRIPE_LIVE_WEBHOOK_KEY.'">';
print ' &nbsp; '.$langs->trans("Example").': whsec_xxxxxxxxxxxxxxxxxxxxxxxx';
print '</td></tr>';

print '<tr class="oddeven"><td>';
print '<span class="fieldrequired">'.$langs->trans("STRIPE_LIVE_WEBHOOK_CONNECT_KEY").'</span></td><td>';
print '<input class="minwidth300" type="text" name="STRIPE_LIVE_WEBHOOK_CONNECT_KEY" value="'.$conf->global->STRIPE_LIVE_WEBHOOK_CONNECT_KEY.'">';
print ' &nbsp; '.$langs->trans("Example").': whsec_xxxxxxxxxxxxxxxxxxxxxxxx';
print '<BR />URL: ';
print '</td></tr>';

print '</table>';

print '<br>';

print '<table class="noborder" width="100%">';
print '<tr class="liste_titre">';
print '<td>'.$langs->trans("UsageParameter").'</td>';
print '<td>'.$langs->trans("Value").'</td>';
print "</tr>\n";

print '<tr class="oddeven"><td>';
print $langs->trans("STRIPE_APPLICATION_FEE_PLATFORM").'</td><td>';
print '<input size="5" type="text" name="STRIPE_APPLICATION_FEE_PERCENT" value="'.price($conf->global->STRIPE_APPLICATION_FEE_PERCENT).'">';
print '% + ';
print '<input size="5" type="text" name="STRIPE_APPLICATION_FEE" value="'.price($conf->global->STRIPE_APPLICATION_FEE).'">';
print ''.$langs->getCurrencySymbol($conf->currency).' avec un minimum de <input size="5" type="text" name="STRIPE_APPLICATION_FEE_MINIMAL" value="'.price($conf->global->STRIPE_APPLICATION_FEE_MINIMAL).'"> '.$langs->getCurrencySymbol($conf->currency).' </td></tr>';

print '<tr class="oddeven"><td>';
print $langs->trans("STRIPE_APPLICATION_FEE_PLATFORM_MINIMAL").'</td><td>';
print '<input size="5" type="text" name="STRIPE_APPLICATION_MENSUAL_MINIMAL" value="'.price($conf->global->STRIPE_APPLICATION_MENSUAL_MINIMAL).'">';
print ''.$langs->getCurrencySymbol($conf->currency).' HT</td></tr>';

	if (! empty($conf->product->enabled) || ! empty($conf->service->enabled))
	{
		print '<tr class="oddeven"><td>'.$langs->trans("STRIPE_APPLICATION_FEE_PRODUCT_ID").'</td>';
		print '<td>';
		$form->select_produits($conf->global->STRIPE_APPLICATION_FEE_PRODUCT_ID, 'STRIPE_APPLICATION_FEE_PRODUCT_ID');
		print '</td></tr>';
	} 

print '</table>';

print '</table>';

dol_fiche_end();

print '<div class="center"><input type="submit" class="button" value="'.$langs->trans("Modify").'"></div>';

print '</form>';

print '<br><br>';


$token='';

include DOL_DOCUMENT_ROOT.'/core/tpl/onlinepaymentlinks.tpl.php';

print info_admin($langs->trans("ExampleOfTestCreditCard", '4242424242424242', '4000000000000101', '4000000000000069', '4000000000000341'));

if (! empty($conf->use_javascript_ajax))
{
	print "\n".'<script type="text/javascript">';
	print '$(document).ready(function () {
            $("#apidoc").hide();
            $("#apidoca").click(function() {
                $("#apidoc").show();
            	$("#apidoca").hide();
            });
    });';
	print '</script>';
}


llxFooter();
$db->close();
