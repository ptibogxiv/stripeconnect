<?php
/*
 * Copyright (C) 2014-2016  Jean-François Ferry	<jfefe@aternatik.fr>
 * 				 2016       Christophe Battarel <christophe@altairis.fr>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/**
 *  \file       htdocs/core/triggers/interface_50_modTicketsup_TicketEmail.class.php
 *  \ingroup    core
 *  \brief      Fichier
 *  \remarks    Son propre fichier d'actions peut etre cree par recopie de celui-ci:
 *              - Le nom du fichier doit etre: interface_99_modMymodule_Mytrigger.class.php
 *                                           ou: interface_99_all_Mytrigger.class.php
 *              - Le fichier doit rester stocke dans core/triggers
 *              - Le nom de la classe doit etre InterfaceMytrigger
 *              - Le nom de la propriete name doit etre Mytrigger
 */
require_once DOL_DOCUMENT_ROOT.'/core/triggers/dolibarrtriggers.class.php';
dol_include_once('/stripeconnect/class/stripeconnect.class.php');
$path=dirname(__FILE__).'/'; 
/**
 *  Class of triggers for ticketsup module
 */
class InterfaceStripeconnect
{
    public $db;

    /**
     *   Constructor
     *
     *   @param DoliDB $db Database handler
     */
    public function __construct($db)
    {
        $this->db = $db;

        $this->name = preg_replace('/^Interface/i', '', get_class($this));
	      $this->family = 'Stripeconnect';
        $this->description = "Triggers of the module Stripeconnect";
        $this->version = 'dolibarr'; // 'development', 'experimental', 'dolibarr' or version
        $this->picto = 'stripeconnect@stripeconnect';
    }

	/**
	 * Trigger name
	 *
	 * @return string Name of trigger file
	 */
	public function getName()
	{
		return $this->name;
	}


	/**
	 * Trigger description
	 *
	 * @return string Description of trigger file
	 */
	public function getDesc()
	{
		return $this->description;
	}

	/**
	 * Trigger version
	 *
	 * @return string Version of trigger file
	 */
	public function getVersion()
	{
		global $langs;
		$langs->load("admin");

		if ($this->version == 'development') {
			return $langs->trans("Development");
		} elseif ($this->version == 'experimental') {
			return $langs->trans("Experimental");
		} elseif ($this->version == 'dolibarr') {
			return DOL_VERSION;
		} elseif ($this->version) {
			return $this->version;
		} else {
			return $langs->trans("Unknown");
		}
	}

	/**
	 * Function called when a Dolibarrr business event is done.
	 * All functions "runTrigger" are triggered if file
	 * is inside directory core/triggers
	 *
	 * @param string $action Event action code
	 * @param CommonObject $object Object
	 * @param User $user Object user
	 * @param Translate $langs Object langs
	 * @param Conf $conf Object conf
	 * @return int              <0 if KO, 0 if no triggered ran, >0 if OK
	 */
   
	public function runTrigger($action, $object, User $user, Translate $langs, Conf $conf)
	{
		// Put here code you want to execute when a Dolibarr business events occurs.
		// Data and type of action are stored into $object and $action
global $langs,$db,$conf;
$langs->load("members");
$langs->load("users");
$langs->load("mails");
$langs->load('other');	
/** Users */
$ok=0; 
$stripeconnect=new StripeConnexion($db);    
if ($action == 'COMPANY_MODIFY') {
			dol_syslog(
				"Trigger '" . $this->name . "' for action '$action' launched by " . __FILE__ . ". id=" . $object->id
			);
if ($stripeconnect->GetStripeAccount($conf->entity)&&$object->client!=0) {  
$cu=$stripeconnect->CustomerStripe($object->id,$stripeconnect->GetStripeAccount($conf->entity));
if ($cu) {    
      if ($conf->entity=='1'){
$customer = \Stripe\Customer::retrieve("$cu->id");
      }else{
$customer = \Stripe\Customer::retrieve("$cu->id",array("stripe_account" => $stripeconnect->GetStripeAccount($conf->entity)));
      }
if (!empty($object->email)) {$customer->email = "$object->email";}
$customer->description = "$object->name";
$customer->save();
}}
    }
elseif ($action == 'COMPANY_DELETE') {
			dol_syslog(
				"Trigger '" . $this->name . "' for action '$action' launched by " . __FILE__ . ". id=" . $object->id
			);
$cu=$stripeconnect->CustomerStripe($object->id,$stripeconnect->GetStripeAccount($conf->entity));
if ($cu) {     
      if ($conf->entity==1){
      $customer = \Stripe\Customer::retrieve("$cu->id");
      }else{
      $customer = \Stripe\Customer::retrieve("$cu->id",array("stripe_account" => $stripeconnect->GetStripeAccount($conf->entity)));
      }
$customer->delete();
}
    }
elseif ($action == 'BILL_PAYED') {
			dol_syslog(
				"Trigger '" . $this->name . "' for action '$action' launched by " . __FILE__ . ". id=" . $object->id
			);     
dol_include_once('/adherentsplus/class/adherent.class.php'); 
require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php';
      
        $sql = "SELECT fk_product, date_start, date_end, total_ttc";               
        $sql.= " FROM ".MAIN_DB_PREFIX."facturedet";
        $sql.= " WHERE fk_facture=".$object->id." ";
        
        $result2 = $db->query($sql);
        if ($result2)
        {
            $num = $db->num_rows($result2);
            $i = 0;

            $var=True;
            while ($i < $num)
            {            
                $objp2 = $db->fetch_object($result2);
                $var=!$var;  
              
if ($objp2->fk_product==$conf->global->ADHERENT_PRODUCT_ID_FOR_SUBSCRIPTIONS) { 

$member=new AdherentPlus($db);
$member->fetch('','',$object->socid);

if ($member->id >0) {
if (empty($conf->global->MEMBER_NO_DEFAULT_LABEL)) {
$adhesion=$langs->trans("Subscription").' '.dol_print_date((strtotime($objp2->date_start)?strtotime($objp2->date_start):time()),"%Y");
} else{
$adhesion=$conf->global->MEMBER_NO_DEFAULT_LABEL;
}
        $sql = "SELECT f.fk_facture,f.fk_paiement,p.rowid, p.fk_bank as bank";               
        $sql.= " FROM ".MAIN_DB_PREFIX."paiement_facture as f";
        $sql.= " JOIN ".MAIN_DB_PREFIX."paiement as p on p.rowid=f.fk_paiement";
        $sql.= " WHERE f.fk_facture=".$object->id." ";
        
		$result3 = $db->query($sql);
    if ($result3)
		{
			if ($db->num_rows($result3))
			{
				$obj = $db->fetch_object($result3);
    $bankkey=$obj->bank;
    }
    }

$idcot=$member->subscription(strtotime($objp2->date_start), $objp2->total_ttc, $bankkey, '', $adhesion, '', '', '', strtotime($objp2->date_end)); 

if ($idcot>0) {
$sql = 'UPDATE '.MAIN_DB_PREFIX.'subscription SET fk_bank='.$bankkey;
$sql.= ' WHERE rowid='.$idcot;
$result = $db->query($sql);
$db->commit();
//$subjecttosend=$member->makeSubstitution($conf->global->ADHERENT_MAIL_COTIS_SUBJECT);
//$texttosend=$member->makeSubstitution($adht->getMailOnSubscription());
//$member->send_an_email($texttosend,$subjecttosend,array(),array(),array(),"","",0,-1);
$invoice = new Facture($db);
$invoice->fetch($object->id);
$invoice->add_object_linked('subscription', $idcot); 
}                              
}                    
            } 
$i++;
        }  }
}       
              
          
 
		return $ok;
	}
}
