<?php
/* Copyright (C) 2017-2018 	PtibogXIV        <support@ptibogxiv.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

use Luracast\Restler\RestException;

require_once DOL_DOCUMENT_ROOT.'/stripe/class/stripe.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/ccountry.class.php';
require_once DOL_DOCUMENT_ROOT.'/commande/class/commande.class.php';
require_once DOL_DOCUMENT_ROOT.'/compta/paiement/class/paiement.class.php';
require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php';
require_once DOL_DOCUMENT_ROOT.'/compta/bank/class/account.class.php';
require_once DOL_DOCUMENT_ROOT.'/societe/class/societe.class.php';

/**
 * API class for towns (content of the ziptown dictionary)
 *
 * @access protected
 * @class DolibarrApiAccess {@requires user,external}
 */
class StripeConnect extends DolibarrApi
{
    /**
     * Constructor
     */
    function __construct()
    {
        global $db,$conf;
        $this->db = $db;
        $this->company = new Societe($this->db);
    }

    /**
     * Get thirdparty stripe's informations.
     *
     * @param 	int 	$id ID of thirdparty
     * @return List of towns
     *            
     * @throws RestException
     */
    function get($id)
    {
    global $db, $conf;

    $result = $this->company->fetch($id);
      if( ! $result ) {
          throw new RestException(404, 'Thirdparty not found');
      }
      
      if( ! DolibarrApi::_checkAccessToResource('societe',$this->company->id)) {
        throw new RestException(401, 'Access not allowed for login '.DolibarrApiAccess::$user->login);
      }
      
$stripe=new Stripe($db); 
$customer=$stripe->CustomerStripe($id,$stripe->GetStripeAccount($conf->entity));
if ($customer->id) {
$input=$customer->sources->data;
}
$list = array();
foreach ($input as $src) {
if ($src->object=='card'){
if ($src->brand == 'Visa') {$brand='cc-visa';}
elseif ($src->brand == 'MasterCard') {$brand='cc-mastercard';}
elseif ($src->brand == 'American Express') {$brand='cc-amex';}
elseif ($src->brand == 'Discover') {$brand='cc-discover';}
elseif ($src->brand == 'JCB') {$brand='cc-jcb';}
elseif ($src->brand == 'Diners Club') {$brand='cc-diners-club';}
else {$brand='credit-card';}
$holder=$src->name;
$reference='****'.$src->last4; 
$expiration=$src->exp_month.'/'.$src->exp_year;
 if ($src->country)
	{
$country=$src->country;
	}
}
elseif ($src->object=='source' && $src->type=='card'){
if ($src->card->brand == 'Visa') {$brand='cc-visa';}
elseif ($src->card->brand == 'MasterCard') {$brand='cc-mastercard';}
elseif ($src->card->brand == 'American Express') {$brand='cc-amex';}
elseif ($src->card->brand == 'Discover') {$brand='cc-discover';}
elseif ($src->card->brand == 'JCB') {$brand='cc-jcb';}
elseif ($src->card->brand == 'Diners Club') {$brand='cc-diners-club';}
else {$brand='credit-card';}
$holder=$src->owner->name;
$reference='**** '.$src->card->last4; 
$expiration=$src->card->exp_month.'/'.$src->card->exp_year;
 if ($src->card->country)
	{
$country=$src->card->country;
	}
}
if (($customer->default_source!=$src->id)) {$default="0";}else {$default="1";}
$list[]= array(
				'id' => $src->id,	
				'brand' => $brand,
        'holder' => $holder,
        'reference' => $reference,
        'expiration' => $expiration,
        'country' => $country,
        'default' => $default
			);
}

if (empty($conf->global->STRIPECONNECT_LIVE))
{
	$secret_key = $conf->global->STRIPE_TEST_SECRET_KEY;
	$publishable_key = $conf->global->STRIPE_TEST_PUBLISHABLE_KEY;
}
else 
{
if (empty($conf->global->STRIPE_LIVE))
{
	$secret_key = $conf->global->STRIPE_TEST_SECRET_KEY;
	$publishable_key = $conf->global->STRIPE_TEST_PUBLISHABLE_KEY;
}
else 
{
	$secret_key = $conf->global->STRIPE_LIVE_SECRET_KEY;
	$publishable_key = $conf->global->STRIPE_LIVE_PUBLISHABLE_KEY;
}
}    
  		return array(
      'secret_key' => $secret_key,
      'publishable_key' => $publishable_key,
      'code_account' => $stripe->GetStripeAccount($conf->entity),
      'code_client' => $customer->id,
			'sources' => $list
		);
    }
    
    /**
     * Add a source to a thirdparty
     *
     * @param int $id               ID of thirdparty
     * @param string $token         Token {@from body}
     * @return int  ID of subscription
     *
     * @url POST {id}/addsource
     */
    function createSource($id, $token)
    {
    global $conf,$db;
      if(! DolibarrApiAccess::$user->rights->societe->creer) {
        throw new RestException(401);
      }     
$stripe=new Stripe($this->db);

$statut="success";

//if ($source1->usage=='reusable') {
$customer=$stripe->CustomerStripe($id,$stripe->GetStripeAccount($conf->entity));
$customer->sources->create(array("source" => "".$token.""));
//}
            return array(
            'source' => $stripeSource,
            'statut' => $statut
        );
    }
    
      /**
     * Pay an object
     *
     * @param int $id               ID of thirdparty
     * @param string  $object         Type of object to pay 
     * @param int   $item         Id of object to pay
     * @param string $source         Source {@from body}
     * @param string $url         Return_url {@from body}
     * @return int  ID of subscription
     *
     * @url POST {id}/pay/{object}/{item}
     */
    function paySource($id, $object, $item, $source, $url)
    {
    global $langs,$conf;
      if(! DolibarrApiAccess::$user->rights->societe->creer) {
        throw new RestException(401);
      }

// PDF
$hidedetails = (GETPOST('hidedetails', 'int') ? GETPOST('hidedetails', 'int') : (! empty($conf->global->MAIN_GENERATE_DOCUMENTS_HIDE_DETAILS) ? 1 : 0));
$hidedesc = (GETPOST('hidedesc', 'int') ? GETPOST('hidedesc', 'int') : (! empty($conf->global->MAIN_GENERATE_DOCUMENTS_HIDE_DESC) ? 1 : 0));
$hideref = (GETPOST('hideref', 'int') ? GETPOST('hideref', 'int') : (! empty($conf->global->MAIN_GENERATE_DOCUMENTS_HIDE_REF) ? 1 : 0));
      
$stripe=new Stripe($this->db);
$customer=$stripe->CustomerStripe($id,$stripe->GetStripeAccount($conf->entity));

$pos=strpos($source,'src_');

if ($pos !== false) {
$src = \Stripe\Source::retrieve("$source",array("stripe_account" => $stripe->GetStripeAccount($conf->entity)));
}
else {
$src = \Stripe\Source::create(array(
  "type" => "card",
  "token" => "$source"
),array("stripe_account" => $stripe->GetStripeAccount($conf->entity)));
$source=$src->id;
}


if ($object=='order') {
$order=new Commande($this->db);
$order->fetch($item);
if ($order->statut==0&&$order->billed!=1) {
$order->valid(DolibarrApiAccess::$user,0,0); // id warehouse to change !!!!!!       
$order->fetch($item);
}
if ($order->statut==1&&$order->billed!=1) {
if ($src->type=='card'){
$order->mode_reglement_id='6';
}
elseif ($src->type=='sepa_debit'){
$order->mode_reglement_id='3';
}
$order->update(DolibarrApiAccess::$user,1);
}
else {
$idref=0;
$msg="order already billed";
$error++;
}
				if (empty($conf->global->MAIN_DISABLE_PDF_AUTOUPDATE))
				{
				// Define output language
				$outputlangs = $langs;
				$newlang = GETPOST('lang_id', 'alpha');
				if ($conf->global->MAIN_MULTILANGS && empty($newlang))
					$newlang = $order->thirdparty->default_lang;
				if (! empty($newlang)) {
					$outputlangs = new Translate("", $conf);
					$outputlangs->setDefaultLang($newlang);
				}

				$ret = $order->fetch($order->id); // Reload to get new records
				$order->generateDocument($order->modelpdf, $outputlangs, $hidedetails, $hidedesc, $hideref);
				}
        
$ref=$order->ref;
$currency=$order->multicurrency_code;
$total=price2num($order->total_ttc);
}
elseif ($object=='invoice') {
$invoice = new Facture($this->db);
$invoice->fetch($item);
$paiement = $invoice->getSommePaiement();
$creditnotes=$invoice->getSumCreditNotesUsed();
$deposits=$invoice->getSumDepositsUsed();
$ref=$invoice->ref;
$ifverif=$invoice->socid;
$currency=$invoice->multicurrency_code;
$total=price2num($invoice->total_ttc - $paiement - $creditnotes - $deposits,'MT');
}

if ($item>0)
{
if ($src->object=='source' && $src->type=='card' && isset($src->card->three_d_secure) && (($src->card->three_d_secure=='required') OR ($src->card->three_d_secure=='recommended') OR ($src->card->three_d_secure=='optional' && $total>'100'))){
$stripeamount=round($total*100);
$src2 = \Stripe\Source::create(array(
  "amount" => "$stripeamount",
  "currency" => "$currency",
  "type" => "three_d_secure",
  "three_d_secure" => array(
    "card" => "$source",
  ),
    "metadata" =>  array(
    "source" => $object,
    "idsource" => "".$item."",
    "idcustomer" => "".$id."",
    "customer" => $customer->id
  ),
  "redirect" => array(
    "return_url" => "$url&ref=$ref&statut=pending"
  ),
),array("stripe_account" => $stripe->GetStripeAccount($conf->entity)));

if ($src2->three_d_secure->authenticated==false && $src2->redirect->status=='succeeded') {
$charge=$stripe->CreatePaymentStripe($total,$currency,$object,$item,$source,$customer->id,$stripe->GetStripeAccount($conf->entity));
$redirect_url=$url."&ref=$ref&statut=".$charge->statut;
}
else {
$redirect_url=$src2->redirect->url;
$error++;
}
}else{
$charge=$stripe->CreatePaymentStripe($total,$currency,$object,$item,$source,$customer->id,$stripe->GetStripeAccount($conf->entity));
$redirect_url=$url."&ref=$ref&statut=".$charge->statut;	
}
} 

if (isset($charge->id) && $charge->statut=='error'){
$msg=$charge->message;
$code=$charge->code;
$error++;
}
elseif (isset($charge->id) && $charge->statut=='success' && $object=='order') {
$invoice = new Facture($this->db);
$idinv=$invoice->createFromOrder($order,DolibarrApiAccess::$user);
if ($idinv > 0)
{
	// Change status to validated
	$result=$invoice->validate(DolibarrApiAccess::$user);
	if ($result > 0) {
$invoice->fetch($idinv);
$paiement = $invoice->getSommePaiement();
$creditnotes=$invoice->getSumCreditNotesUsed();
$deposits=$invoice->getSumDepositsUsed();
$ref=$invoice->ref;
$ifverif=$invoice->socid;
$currency=$invoice->multicurrency_code;
$total=price2num($invoice->total_ttc - $paiement - $creditnotes - $deposits,'MT');
}
	else
	{
$msg=$invoice->error; 
$error++;
	}
}
else
{
$msg=$invoice->error;
$error++;
} 
}

      if (!$error)
      {           
$datepaye = dol_now();
$paiementcode ="CB"; 
$amounts=array(); 
$amounts[$invoice->id] = $total;
$multicurrency_amounts=array();
//$multicurrency_amounts[$item] = $total; 
      // Creation of payment line
	    $paiement = new Paiement($this->db);
	    $paiement->datepaye     = $datepaye;
	    $paiement->amounts      = $amounts;   // Array with all payments dispatching
	    $paiement->multicurrency_amounts = $multicurrency_amounts;   // Array with all payments dispatching
      $paiement->paiementid   = dol_getIdFromCode($this->db,$paiementcode,'c_paiement','code','id',1);
	    $paiement->num_paiement = $charge->message;
	    $paiement->note         = '';
}
      if (! $error)
	    {
	    $paiement_id=$paiement->create(DolibarrApiAccess::$user, 0);
  
if (empty($conf->global->MAIN_DISABLE_PDF_AUTOUPDATE) && count($invoice->lines))
			{
				$outputlangs = $langs;
				$newlang = '';
				if ($conf->global->MAIN_MULTILANGS && empty($newlang) && GETPOST('lang_id','aZ09')) $newlang = GETPOST('lang_id','aZ09');
				if ($conf->global->MAIN_MULTILANGS && empty($newlang))	$newlang = $invoice->thirdparty->default_lang;
				if (! empty($newlang)) {
					$outputlangs = new Translate("", $conf);
					$outputlangs->setDefaultLang($newlang);
				}
				$model=$invoice->modelpdf;
				$ret = $invoice->fetch($invoice->id); // Reload to get new records

				$invoice->generateDocument($model, $outputlangs, $hidedetails, $hidedesc, $hideref);

			}         
	    	if ($paiement_id < 0)
	        {
	            $msg=$paiement->errors;
	            $error++;
	        }else{ 
        if ($object=='order') {
        $order->classifyBilled(DolibarrApiAccess::$user);
        }        
          }
	    }
      
	    if (! $error)
	    {
	    	$label='(CustomerInvoicePayment)';
	    	if (GETPOST('type') == 2) $label='(CustomerInvoicePaymentBack)';
	        $paiement->addPaymentToBank(DolibarrApiAccess::$user,'payment',$label,$conf->global->STRIPE_BANK_ACCOUNT_FOR_PAYMENTS,'','');
	        if ($result < 0)
	        {
	            $msg=$paiement->errors;
	            $error++;
	        } 
$invoice->set_paid(DolibarrApiAccess::$user);                    
	    }          
            return array(
            'charge' => $charge->id,
            'statut' => $charge->statut,
            'redirect_url' => $redirect_url,
            'code' => $code,
            'message' => $msg
        );
    } 
    
    /**
     * Set a default source to a thirdparty
     *
     * @param int $id               ID of thirdparty
     * @param string $source         Source {@from body}
     * @return int  ID of subscription
     *
     * @url PUT {id}/defaultsource
     */
    function defaultSource($id, $source)
    {
    global $db, $conf;
      if(! DolibarrApiAccess::$user->rights->societe->creer) {
        throw new RestException(401);
      }
      
$stripe=new Stripe($db);
$customer=$stripe->CustomerStripe($id,$stripe->GetStripeAccount($conf->entity));
$customer->default_source=$source;
$customer->save();

        return $source;
    }    
        /**
     * Delete source to a thirdparty
     *
     * @param int		$id	Id of thirdparty
     * @param string		$srcid	Id of source
     *
     * @return mixed
     *
     * @url DELETE {id}/deletesource/{srcid}
     */
    function deleteSource($id, $srcid) {
    global $db, $conf;
      if(! DolibarrApiAccess::$user->rights->societe->creer) {
        throw new RestException(401);
      }
      
$stripe=new Stripe($db);
$customer=$stripe->CustomerStripe($id,$stripe->GetStripeAccount($conf->entity));
//$cu = \Stripe\Customer::retrieve("".$id."",array("stripe_account" => $stripe->GetStripeAccount($conf->entity)));
$customer->sources->retrieve("$srcid")->detach(); 
                                                                
        return array(
            'success' => array(
                'code' => 200,
                'message' => 'Source deleted'
            )
        );
    
    }

}
